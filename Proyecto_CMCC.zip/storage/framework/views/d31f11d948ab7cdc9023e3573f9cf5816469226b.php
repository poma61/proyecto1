<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Probando React</title>
</head>
<body>
    <h1>HOLA MUNDO</h1>
    <P>COMO ESTAS</P>
</body>
</html><?php /**PATH C:\laragon\www\Proyecto_CMC\resources\views/prueba.blade.php ENDPATH**/ ?>